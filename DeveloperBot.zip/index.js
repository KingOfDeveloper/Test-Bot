const Discord = require('discord.js');
const superagent = require('superagent');
const randomPuppy = require('random-puppy');
const db = require("quick.db")



const client = new Discord.Client();

const version = "1.0"

const prefix = "!"

const fs = require('fs');
const ms = require("ms");
let cooldown = new Set();

const i18n = require("i18n");



client.commands = new Discord.Collection();
const commandsFiles = fs.readdirSync('./commands/').filter(file => file.endsWith('.js'));
for(const file of commandsFiles){
    const command = require(`./commands/${file}`);

    client.commands.set(command.name, command);
}

const guildFiles = fs.readdirSync('./guild/').filter(file => file.endsWith('.js'));
for(const file of guildFiles){
    const command = require(`./guild/${file}`);

    client.commands.set(command.name, command);
}
const welcomeFiles = fs.readdirSync('./welcome/').filter(file => file.endsWith('.js'));
for(const file of welcomeFiles){
    const command = require(`./welcome/${file}`);

    client.commands.set(command.name, command);
}


const funFiles = fs.readdirSync('./fun/').filter(file => file.endsWith('.js'));
for(const file of funFiles){
    const command = require(`./fun/${file}`);

    client.commands.set(command.name, command);
}

const moneysystemFiles = fs.readdirSync('./moneysystem/').filter(file => file.endsWith('.js'));
for(const file of moneysystemFiles){
    const command = require(`./moneysystem/${file}`);

    client.commands.set(command.name, command);
}
const moderationFiles = fs.readdirSync('./moderation/').filter(file => file.endsWith('.js'));
for(const file of moderationFiles){
    const command = require(`./moderation/${file}`);

    client.commands.set(command.name, command);
}
const memberFiles = fs.readdirSync('./member/').filter(file => file.endsWith('.js'));
for(const file of memberFiles){
    const command = require(`./member/${file}`);

    client.commands.set(command.name, command);
}
const musicFiles = fs.readdirSync('./music/').filter(file => file.endsWith('.js'));
for(const file of musicFiles){
    const command = require(`./music/${file}`);

    client.commands.set(command.name, command);
}

client.on("ready", () => {
  console.log('${bot.user.username} elindult!')

  let statuszok = [
      "prefix : !",
      "Creator: Attila#8171",
      "My Name is $OfficalJs",
      `Szervereim: ${client.guilds.cache.size}`,
      "If have questen pls send it to Attila#8171!",


  ]

  setInterval(function(){
      let status = statuszok[Math.floor(Math.random()* statuszok.length)]

      client.user.setActivity(status, {type: "PLAYING"})
  }, 3000)
});
client.on("message", message => {
    if(message.author.bot) return;
    if (message.content.indexOf(prefix) !== 0) return;

    const args = message.content.slice(prefix.length).trim().split(/ +/g);
    const cmd = args.shift().toLowerCase()
        if (cmd === "help") {
            const helpEmbed = new Discord.MessageEmbed()
                    .setColor("BLACK")
                    .setThumbnail("https://cdn.discordapp.com/avatars/841325357964853268/f6b44ca6022478b54fae26244f51ce04.webp")
                    .setTitle(`${client.user.username}'s Help Menu`)
                    .setDescription(`**PREFIX: \`${prefix}\`**`)
                    .addField("` help-member ` ` help-moderator ` ` help-fun ` ` help-music ` `help-guild` `help-money` `help-nsfw` ", "Bot commands.")
      
            message.channel.send(helpEmbed)
        }
    });
    client.on("message", message => {
    if(message.author.bot) return;
    if (message.content.indexOf(prefix) !== 0) return;

    const args = message.content.slice(prefix.length).trim().split(/ +/g);
    const cmd = args.shift().toLowerCase()
        if (cmd === "help-money") {
            const moneyEmbed = new Discord.MessageEmbed()
                    .setColor("BLACK")
                    .setThumbnail("https://cdn.discordapp.com/avatars/841325357964853268/f6b44ca6022478b54fae26244f51ce04.webp")
                    .setTitle(`${client.user.username}'s Help-Moneysystem`)
                    .setDescription(`**PREFIX: \`${prefix}\`**`)
                    .addField("`bal` `beg` `crime` `rob` `work`" , "For You")
      
            message.channel.send(moneyEmbed)
        }
    });
    client.on("message", message => {
    if(message.author.bot) return;
    if (message.content.indexOf(prefix) !== 0) return;

    const args = message.content.slice(prefix.length).trim().split(/ +/g);
    const cmd = args.shift().toLowerCase()
        if (cmd === "help-nsfw") {
            const nsfwEmbed = new Discord.MessageEmbed()
                    .setColor("BLACK")
                    .setThumbnail("https://cdn.discordapp.com/avatars/841325357964853268/f6b44ca6022478b54fae26244f51ce04.webp")
                    .setTitle(`${client.user.username}'s  NSFW Help Menu`)
                    .setDescription(`**PREFIX: \`${prefix}\`**`)
                    .addField("coming soon")
      
            message.channel.send(nsfwEmbed)
        }
    });
    client.on("message", message => {
      if(message.author.bot) return;
      if (message.content.indexOf(prefix) !== 0) return;
  
      const args = message.content.slice(prefix.length).trim().split(/ +/g);
      const cmd = args.shift().toLowerCase()
          if (cmd === "help-music") {
              const musicEmbed = new Discord.MessageEmbed()
              
                      .setColor("BLACK")
                      .setThumbnail("https://cdn.discordapp.com/avatars/841325357964853268/f6b44ca6022478b54fae26244f51ce04.webp")
                      .setTitle(`${client.user.username}'s Help Menu`)
                      .setDescription(`**PREFIX: \`${prefix}\`**`)
                      .addField("`play` `leave` `pause` `resume` `queue` `clear-queue` `shuffle` `np` `volume` `skip` `stop` `loop`" )
              message.channel.send(musicEmbed)
          }
      });
    client.on("message", message => {
        if(message.author.bot) return;
        if (message.content.indexOf(prefix) !== 0) return;
    
        const args = message.content.slice(prefix.length).trim().split(/ +/g);
        const cmd = args.shift().toLowerCase()
            if (cmd === "help-moderator") {
                const modEmbed = new Discord.MessageEmbed()
                        .setColor("BLACK")
                        .setTitle(`${client.user.username}'s Moderator commands`)
                        .setThumbnail("https://cdn.discordapp.com/avatars/841325357964853268/f6b44ca6022478b54fae26244f51ce04.webp")
                        .setDescription(`**PREFIX: \`${prefix}\`**`)
                        .addField("`ban` `kick` `clear` `mute` `unmute` `sign` `say` `slowmode` `nickname` `rank` `suggestions` `nuke` `unban` `createrole`", "For moderators!")
                       
                message.channel.send(modEmbed)
            }
        });
        client.on("message", message => {
        if(message.author.bot) return;
        if (message.content.indexOf(prefix) !== 0) return;
    
        const args = message.content.slice(prefix.length).trim().split(/ +/g);
        const cmd = args.shift().toLowerCase()
            if (cmd === "help-guild") {
                const guildEmbed = new Discord.MessageEmbed()
                        .setColor("BLACK")
                        .setTitle(`${client.user.username}'s Guild commands`)
                        .setThumbnail("https://cdn.discordapp.com/avatars/841325357964853268/f6b44ca6022478b54fae26244f51ce04.webp")
                        .setDescription(`**PREFIX: \`${prefix}\`**`)
                        .addField("`info` `server-info`")
                       
                message.channel.send(guildEmbed)
            }
        });
        client.on("message", message => {
            if(message.author.bot) return;
            if (message.content.indexOf(prefix) !== 0) return;
        
            const args = message.content.slice(prefix.length).trim().split(/ +/g);
            const cmd = args.shift().toLowerCase()
                if (cmd === "help-fun") {
                    const funEmbed = new Discord.MessageEmbed()
                            .setColor("BLACK")
                            .setTitle(`${client.user.username}'s Fun commands`)
                            .setThumbnail("https://cdn.discordapp.com/avatars/841325357964853268/f6b44ca6022478b54fae26244f51ce04.webp")
                            .setDescription(`**PREFIX: \`${prefix}\`**`)
                            .addField("`avatar` `weather` `cat` `meme` `animesearch` `rps` `coinflip` `gay` `reverse` `ascii` `deepfry` `cuterate` `8ball` `kvíz` `meme` ", "For fun!")
                           
                    message.channel.send(funEmbed)
                }
            });
            client.on("message", message => {
                if(message.author.bot) return;
                if (message.content.indexOf(prefix) !== 0) return;
            
                const args = message.content.slice(prefix.length).trim().split(/ +/g);
                const cmd = args.shift().toLowerCase()
                    if (cmd === "help-member") {
                        const memberEmbed = new Discord.MessageEmbed()
                                .setColor("BLACK")
                                .setTitle(`${client.user.username}'s Member commands`)
                                .setThumbnail("https://cdn.discordapp.com/avatars/841325357964853268/f6b44ca6022478b54fae26244f51ce04.webp")
                                .setDescription(`**PREFIX: \`${prefix}\`**`)
                                .addField("`date`  `prefix`  `rules`  `bugreport`  `report`  `embed`  `website`  `social` `bot`, `ticket` `corona` `delemoji` `enlarge` `invite` `leaderboard` `poll` `snipe` `uptime` `youtube` `social`", "For members!")

                        message.channel.send(memberEmbed)
                    }
                });
client.on('message', message =>{
  if(!message.content.startsWith(prefix) || message.author.bot) return;

  const args = message.content.slice(prefix.length).split(/ +/);
  const command = args.shift().toLowerCase();

  if(command === 'rules') {
    client.commands.get('rules').execute(message, args)
  } else if (command === 'avatar') {
    client.commands.get('avatar').execute(client, message, args)
  } else if (command === 'ban') {
    client.commands.get('ban').execute(message, args)
  } else if (command === ' clear') {
    client.commands.get('clear').execute(message, args)
  } else if (command === 'date') {
    client.commands.get('date').execute(message, args)
  } else if (command === 'kick') {
    client.commands.get('kick').execute(message, args)
  } else if ( command === 'mute') {
    client.commands.get('mute').execute(client, message, args)
  } else if (command === 'ping') {
    client.commands.get('ping').execute(client, message, args)
  } else if (command === 'prefix') {
    client.commands.get('prefix').execute(message, args)
  } else if (command === 'report') {
    client.commands.get('report').execute(message, args)
  } else if (command === 'say') {
    client.commands.get('say').execute(message, args)
  } else if (command === 'sign') {
    client.commands.get('sign').execute(message, args)
  } else if (command === 'unmute') {
    client.commands.get('unmute').execute(client, message, args)
  } else if (command === 'youtube') {
    client.commands.get('youtube').execute(message, args)
  } else if (command === 'info') {
    client.commands.get('info').execute(message, args)
  } else if (command === 'server-info') {
    client.commands.get('server-info').execute(message, args)
  } else if (command === 'bugreport') {
    client.commands.get('bugreport').execute(message, args, client, Discord)
  } else if (command === 'slowmode') {
    client.commands.get('slowmode').execute(message, args)
  } else if (command === 'weather') {
    client.commands.get('weather').execute(client, message, args)
  } else if (command === 'embed') {
    client.commands.get('embed').execute(client, message, args)
  } else if (command === 'social') {
    client.commands.get('social').execute(message, args)
  } else if (command === 'nickname') {
    client.commands.get('nickname').execute(message, args, client)
  } else if (command === 'nickname') {
    client.commands.get('nickname').execute(message, args, client)
  } else if (command === 'website') {
    client.commands.get('website').execute(message, args)
  } else if (command === 'clear') {
    client.commands.get('clear').execute(message, args)
  } else if (command === 'ticket') {
    client.commands.get('ticket').execute(message, args, client, Discord)
  } else if (command === 'suggestions') {
    client.commands.get('suggestions').execute(message, args, client, Discord)
  } else if (command === 'leave') {
    client.commands.get('leave').execute(client, message, args)
  } else if (command === 'rank') {
    client.commands.get('rank').execute(message, args)
  } else if (command === 'cat') {
    client.commands.get('cat').execute(client, message, args)
  } else if (command === 'meme') {
    client.commands.get('meme').execute(client, message, args)
  } else if (command === 'animesearch') {
    client.commands.get('animesearch').execute( message, args)
  } else if (command === 'gay') {
    client.commands.get('gay').execute( message, args)
  } else if (command === 'invite') {
    client.commands.get('invite').execute( message, args)
  } else if (command === 'corona') {
    client.commands.get('corona').execute( message, args)
  } else if (command === 'ascii') {
    client.commands.get('ascii').execute( message, args)
  } else if (command === 'bal') {
    client.commands.get('bal').execute( message, args)
  } else if (command === 'beg') {
    client.commands.get('beg').execute( message, args)
  } else if (command === 'crime') {
    client.commands.get('crime').execute( message, args)
  }  else if (command === 'cuterate') {
    client.commands.get('cuterate').execute( message, args)
  } else if (command === 'delemoji') {
    client.commands.get('delemoji').execute( message, args)
  } else if (command === 'enlarge') {
    client.commands.get('enlarge').execute( message, args)
  } else if (command === 'leaderboard') {
    client.commands.get('leaderboard').execute( message, args)
  } else if (command === 'poll') {
    client.commands.get('poll').execute( message, args)
  } else if (command === 'rob') {
    client.commands.get('rob').execute( message, args)
  } else if (command === 'work') {
    client.commands.get('work').execute( message, args)
  } else if (command === 'snipe') {
    client.commands.get('snipe').execute( message, args)
  } else if (command === 'uptime') {
    client.commands.get('uptime').execute(message, args, client)
  } else if (command === 'deepfry') {
    client.commands.get('deepfry').execute(client, message, args)
  } else if (command === 'coinflip') {
    client.commands.get('coinflip').execute(client, message, args)
  } else if (command === 'reverse') {
    client.commands.get('reverse').execute(client, message, args)
  } else if (command === 'rps') {
    client.commands.get('rps').execute(client, message, args)
  } else if (command === 'nuke') {
    client.commands.get('nuke').execute(client, message, args)
  } else if (command === 'play') {
    client.commands.get('play').execute(client, message, args,)
  } else if (command === 'skip') {
    client.commands.get('skip').execute(client, message, args)
  } else if (command === 'stop') {
    client.commands.get('stop').execute(client, message, args)
  } else if (command === 'nowplaying') {
    client.commands.get('nowplaying').execute(client, message, args)
  } else if (command === 'loop') {
    client.commands.get('loop').execute(message, args)
  } else if (command === 'queue') {
    client.commands.get('queue').execute(client, message, args)
  } else if (command === 'skipall') {
    client.commands.get('skipall').execute(client, message, args)
  } else if (command === 'pause') {
    client.commands.get('pause').execute(message, args)
  } else if (command === 'unpause') {
    client.commands.get('unpause').execute(message, args)
  } else if (command === 'volume') {
    client.commands.get('volume').execute(client, message, args)
  } else if (command === 'shuffle') {
    client.commands.get('shuffle').execute(client, message, args)
  } else if (command === 'resume') {
    client.commands.get('resume').execute(client, message, args)
  }else if (command === 'join') {
    client.commands.get('join').execute(client, message, args)
  } else if (command === 'giveaway') {
    client.commands.get('giveaway').execute(client, message, args)
  } else if (command === 'filters') {
    client.commands.get('giveaway').execute(client, message, args)
  } else if (command === 'createrole') {
    client.commands.get('createrole').execute(client, message, args)
  } else if (command === 'badwords') {
    client.commands.get('badwords').execute(client, message, args)
  } else if (command === 'addrole') {
    client.commands.get('addrole').execute(client, message, args)
  } else if (command === 'setstatus') {
    client.commands.get('setstatus').execute(client, message, args)
  } else if (command === '8ball') {
    client.commands.get('8ball').execute(client, message, args)
  } else if (command === 'level') {
    client.commands.get('level').execute(client, message, args)
  } else if (command === 'setprefix') {
    client.commands.get('setprefix').execute(client, message, args)
  } else if (command === 'kviz') {
    client.commands.get('kviz').execute(client, message, args)
  } else if (command === 'rr') {
    client.commands.get('rr').execute(message, args, Discord, client)
  }
  else if (command === 'help-v') {
    client.commands.get('help-v').execute(client, message, args)
  }
  else if (command === 'rrvrole') {
    client.commands.get('rrvrole').execute(client, message, args)
  }
  else if (command === 'rvchannel') {
    client.commands.get('rvchannel').execute(client, message, args)
  }
  else if (command === 'rvrole') {
    client.commands.get('rvrole').execute(client, message, args)
  }
  else if (command === 'setrole') {
    client.commands.get('setrole').execute(client, message, args)
  }
  else if (command === 'setrrole') {
    client.commands.get('setrrole').execute(client, message, args)
  }
  else if (command === 'setverify') {
    client.commands.get('setverify').execute(client, message, args)
  }
  else if (command === 'accept') {
    client.commands.get('accept').execute(client, message, args)
  }
   else if (command === 'helpmc') {
    client.commands.get('helpmc').execute(client, message, args)
  }
  else if (command === 'helpw') {
    client.commands.get('helpw').execute(client, message, args)
  }


  if(message.content.startsWith(prefix + "bot")) {
    message.channel.send(`**$OfficalJs Bot Info**\n\n**Developer: Attila**\n**Language: JavaScript**\n**Verzion: ${version}**\n**Prefix: ${prefix}**\n**Szerverek: ${client.guilds.size}**\n**Létrehozva: ${client.user.createdAt.toDateString()}**`);
}
});

client.login("OTE2NDM3MjYzNzQ1OTQ1NjIw.YaqItg.J4B8GMIbfb7H-ZQ3xwDPSWpQHrE")

module.exports = {
	name: 'youtube',
	description: 'This command show my yt channel!',
	execute(message, args) {
        message.channel.send("https://www.youtube.com/channel/UC2g7xN05n8GjopIRxe8Gj5Q")
    }
}
module.exports = {
    name: "createrole",
    description: "",
    execute(client, message, args) {
        if(message.guild.member(client.user).hasPermission("ADMINISTRATOR")) {
            if(message.member.hasPermission("MANAGE_ROLES")){
                if(args[0]){
                    message.guild.roles.create({
                        data: {
                        "name": args[0],
                        }
                    }).then(message.reply(`${message.author.tag} Sucessful!`))

                } else message.reply('Usage: ${prefix}createroles <role name>')

            } else message.reply("I see you dont have the correct permission!")

        } else message.reply("The bot dont have Administrator role! Pls give to 'he'!")
    }
}

module.exports = {
    name: "nickname",
    aliases: ["nickname"],
    description: "set nickname to guild member!",
    execute(message, args, client) {
        const userTarget = message.mentions.users.first();
        if(!userTarget) {
            message.channel.send("Add @+name");
            return;
        }

        const memberTarget = message.guild.members.cache.get(userTarget.id);

        const newNickname = args.slice(1).join(' ');
        if(!newNickname) {
            message.channel.send("Pls add new name");
            return;
        }

        memberTarget.setNickname(newNickname);
    }
}

// !nickname @wzimanka <nowy nickname>
module.exports = {
    name: "setstatus",
    category: "Egyeb",
    description: "Státusz átváltoztatás Parancs.",
    usage: "<status> <type> <name>",
    permission: 'Fejlesztő',
    execute(client, message, args) {

    if(message.author.id != `${'676850692371251215' || '676850692371251215'}`) return message.reply(' Hééé!! Neked nincs jogod ehhez! ')
    let type = args[1];
    let name = args.slice(2).join(" ");;
    let status = args[0];
    if(!status) return message.reply('kérlek adj meg egy statust.')
    if(status && !['online', 'dnd', 'idle', 'invisible'].includes(args[0])) return message.channel.send('Statusok: online, dnd, idle, invisible') 
    if(!args[1]) return message.reply('kérlek adj meg egy typet.')
    if(args[1] && !['STREAMING', 'PLAYING', 'WATCHING', 'LISTENING'].includes(args[1])) return message.channel.send('Typeok: STREAMING, PLAYING, WATCHING, LISTENING');
    if(!name) return message.channel.send('Kérlek add meg a nevét!');
    try{
        client.user.setPresence({
            status: status,
            game: {
              name: name,
              type: type,
              url: 'https://amongsus.cf/supportdc'
            }
        });
    }catch(err) {
        
        if(err) console.error(err)
        if(err) return message.channel.send('Kérlek próbáld újra később!')
    }
    message.reply('Nézd meg miben játszok!')

}
}
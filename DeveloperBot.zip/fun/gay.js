const Discord = require("discord.js")


module.exports = {
    name: 'gay',
    description: 'Mennyire vagy buzi?',
    usage: 'gay [user]',
    usage: 'gay',
    category: 'Fun',
    guildOnly: true,
    async execute(message, args){
        let User = await message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.guild.members.cache.find(r => r.user.username.toLowerCase().includes() === args.join(' ').toLocaleLowerCase()) || message.guild.members.cache.find(r => r.displayName.toLowerCase().includes() === args.join(' ').toLocaleLowerCase())
        let gayrate = Math.floor(Math.random() * 101)


        if(!User){
            let gayrateEmbed = new Discord.MessageEmbed()
                .setTitle("Gay Machine")
                .setColor("RANDOM")
                .setDescription("You gay %?: `" + gayrate + "%` GAY!! 🏳️‍🌈")
                .setFooter(message.client.user.username, message.client.user.avatarURL())
                .setTimestamp(message.createdAt)
            message.channel.send(gayrateEmbed).catch(e => {
                console.log(e)
            })
        } else {
            let argsEmbed = new Discord.MessageEmbed()
                .setTitle("Gayrate Machine")
                .setColor("RANDOM")
                .setDescription(`${User.user.username} ő \`${gayrate}%\` GAY! 🏳️‍🌈`)
                .setFooter(message.client.user.username, message.client.user.avatarURL())
                .setTimestamp(message.createdAt)
            message.channel.send(argsEmbed).catch(e => {
                console.log(e)
            })
        }
    }
}
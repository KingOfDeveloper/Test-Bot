const { MessageEmbed } = require("discord.js");
const { prefix,} = require("../../config.json")
module.exports = {
  name: "helpw",
  description:
    "Get list of all command and even get to know every command detials",
  usage: "help <cmd>",
  category: ":frame_photo: WELCOME",
  execute(client, message, args) {
  
    if (args[0]) {
      const command = client.commands.get(args[0]);

      if (!command) {
        return message.channel.send("Unknown Command: " + args[0]);
      }

      let embed = new MessageEmbed()
            .setcolot("BLACK")
.setTitle('Here can see the welcome message futures!')
        .setDescription('`reset` `setdesc` `setnail` `test` `setwelchn`')

      return message.channel.send(embed).then(m => m.delete({ timeout: 8000 }));
    } else {
      const commands = client.commands;
          message.channel.send(embed)
          

    }
  }
};

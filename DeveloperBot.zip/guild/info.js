const Discord = require('discord.js');

module.exports = {
	name: 'info',
	description: '.',
	execute(message, args) {
        let user = message.mentions.users.first() || message.author;
        if(user.presence.status === `dnd`) user.presence.status = "Elfoglalt";
        if(user.presence.status === `idle`) user.presence.status = "Tétlen";
        if(user.presence.status === `offline`) user.presence.status = "Láthatatlan";
        if(user.presence.status === `online`) user.presence.status = "Elérhető";
        if(user.presence.status === null) user.presence.game = "Nem játszik";
        const member = message.guild.member(user)
        const exampleEmbed = new Discord.MessageEmbed()
        
        .setColor("BLACK")
        .setTitle(`${user.username} Információi`, user.displayAvatarURL)
        .addField("Felhasználóneve:", user.username)
        .addField("ID:", user.id)
        .addField("Játékban:", user.presence.game)
        .addField("Állapota:", user.presence.status)
        .addField('Roles', `<@&${member._roles.join('> <@&')}>`)
        .addField("Létrehozva:", user.createdAt.toDateString())
        .addField("Csatlakozott a szerverhez:", member.joinedAt.toDateString())
        message.channel.send(exampleEmbed)
    }
}
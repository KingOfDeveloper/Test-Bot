module.exports = async (client) =>{
    const guild = client.guilds.cache.get('');
    setInternal(() =>{
        const memberCount = guild.memberCount;
        const channel = guild.channels.cache.get('');
        channel.setName(`Total Members: ${memberCount.tolocaleString()}`)
        console.log('Updating Member Count');
    }, 5000);
}
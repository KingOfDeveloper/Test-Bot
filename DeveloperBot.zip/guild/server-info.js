const Discord = require('discord.js');

module.exports = {
	name: 'server-info',
	description: '',
	execute(message, args) {
         let exampleEmbed = new Discord.MessageEmbed()
        .setColor("BLACK")
        .setTitle("Szerver Információk")
        .addField("Discord Server Name:", `${message.guild.name}`)
        .addField("Discord Server Owner:", `${message.guild.owner}`)
        .addField("Members:", `${message.guild.memberCount}`)
        .addField(`Rangok:\nÖsszesen van ${message.guild.roles.cache.size} rang a szerveren.`)
        message.channel.send(exampleEmbed)
    }
}